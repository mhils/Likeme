//Create fake LikeEvent
fakeEdgeCreate = document.createElement('script');
fakeEdgeCreate.innerHTML = "UnverifiedXD.send({type: 'edgeCreated'});";
document.body.appendChild(fakeEdgeCreate);